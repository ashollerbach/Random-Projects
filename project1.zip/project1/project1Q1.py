import numpy as np

trials = 50 #50 trials
coin_flips = np.random.randint(0, 2, trials) #
heads_count = np.sum(coin_flips == 1)
prob = heads_count/trials
print(prob)